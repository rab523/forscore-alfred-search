set -eu
progress="$HOME/Library/Application Support/forScore Alfred/forscore-progress.tsv"
/usr/bin/perl -pe 's/\|\|\|(?=forscore:\/\/open\?)/\t/g' >> "$progress"
/usr/bin/printf '\n' >> "$progress"
