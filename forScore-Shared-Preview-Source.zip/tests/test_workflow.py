"""Run with python3 -m unittest discover -s tests from the project root.

Tests substitute an isolated data folder in copies of the shipped scripts.
They never change HOME or read/write a real user's index.
"""
import json
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.data = Path(self.temp.name) / 'data with spaces'
        self.data.mkdir()

    def shell(self, name, data=''):
        script = (ROOT / 'shortcut-scripts' / name).read_text()
        for prefix in ('$HOME', '$ENV{HOME}'):
            script = script.replace(prefix + '/Library/Application Support/forScore Alfred', str(self.data))
        return subprocess.run(['/bin/bash', '-c', script], input=data, text=True, capture_output=True)

    def search(self, query=''):
        script = (ROOT / 'workflow/search.pl').read_text().replace(
            '$ENV{HOME}/Library/Application Support/forScore Alfred', str(self.data))
        p = subprocess.run(['/usr/bin/perl', '-e', script, query], capture_output=True, check=True)
        return json.loads(p.stdout)['items']

    def test_missing_index(self):
        self.assertFalse(self.search()[0]['valid'])
        self.assertIn('Run Export', self.search()[0]['title'])

    def test_export_search_copy_and_duplicates(self):
        self.assertEqual(self.shell('initialize.sh').returncode, 0)
        score = 'Book\tforscore://open?path=Book%2520One.pdf\n'
        mark = 'Étude [A]|||forscore://open?path=Book%2520One.pdf&bookmark=%25C3%2589tude\n'
        self.assertEqual(self.shell('append.sh', score).returncode, 0)
        self.assertEqual(self.shell('append.sh', mark).returncode, 0)
        self.assertEqual(self.shell('append.sh', mark).returncode, 0)
        p = self.shell('finalize.sh')
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertIn('2 forScore items indexed', p.stdout)
        results = self.search('ETUDE book one')
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['title'], 'Étude [A]')
        self.assertEqual(results[0]['subtitle'], 'Bookmark • Book One.pdf')
        self.assertEqual(results[0]['text']['copy'], '[Étude \\[A\\]](<forscore://open?path=Book%2520One.pdf&bookmark=%25C3%2589tude>)')
        self.assertFalse(self.search('no-such-title')[0]['valid'])
        self.assertEqual(self.shell('initialize.sh').returncode, 0)
        self.assertEqual(len(list(self.data.glob('forscore-progress-*.tsv'))), 1)
        self.assertEqual(len(self.search()), 2)

    def test_empty_or_invalid_export_preserves_good_index(self):
        target = self.data / 'forscore-index.tsv'
        target.write_text('Previously valid index')
        for invalid in ('', 'Broken row\n', 'Title\tforscore://open?bookmark=MissingPath\n'):
            (self.data / 'forscore-progress.tsv').write_text(invalid)
            self.assertNotEqual(self.shell('finalize.sh').returncode, 0)
            self.assertEqual(target.read_text(), 'Previously valid index')

    def test_result_limit(self):
        (self.data / 'forscore-index.tsv').write_text(''.join(
            f'Score {i}\tforscore://open?path=score{i}.pdf\n' for i in range(250)))
        self.assertEqual(len(self.search()), 200)


if __name__ == '__main__':
    unittest.main()
