case "$1" in
  forscore://open\?*) /usr/bin/open "$1" ;;
esac
