set -eu
dir="$HOME/Library/Application Support/forScore Alfred"
/bin/mkdir -p "$dir"
if [ -f "$dir/forscore-progress.tsv" ]; then
  /bin/mv "$dir/forscore-progress.tsv" "$dir/forscore-progress-$(/bin/date +%Y%m%d-%H%M%S)-$$.tsv"
fi
: > "$dir/forscore-progress.tsv"
