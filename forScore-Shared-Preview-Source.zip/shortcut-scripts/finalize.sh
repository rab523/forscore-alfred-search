set -eu
/usr/bin/perl - <<'PERL'
use strict;
use warnings;
use File::Temp qw(tempfile);
my $dir = "$ENV{HOME}/Library/Application Support/forScore Alfred";
open my $in, '<:raw', "$dir/forscore-progress.tsv" or die "Cannot read export: $!\n";
my (%records, @order);
while (my $row = <$in>) {
    $row =~ s/\r?\n\z//;
    next if $row =~ /^\s*$/;
    my ($title, $url) = $row =~ /\A(.+)\t(forscore:\/\/open\?[^\s<>]+)\z/;
    die "Invalid index record; previous index preserved.\n"
        unless defined $url && $url =~ /[?&]path=[^&]+/;
    push @order, $url unless exists $records{$url};
    $records{$url} = $title;
}
close $in or die "Cannot finish reading export: $!\n";
die "No index records; previous index preserved.\n" unless @order;
my ($out, $tmp) = tempfile('forscore-index-XXXXXX', DIR => $dir, UNLINK => 1);
binmode $out, ':raw';
for my $url (@order) { print {$out} "$records{$url}\t$url\n" or die "Cannot write index: $!\n"; }
close $out or die "Cannot save index: $!\n";
rename $tmp, "$dir/forscore-index.tsv" or die "Cannot replace index: $!\n";
print scalar(@order), " forScore items indexed\n";
PERL
