use strict;
use warnings;
use feature 'fc';
use Encode qw(decode encode FB_CROAK);
use Unicode::Normalize qw(NFKD);
use JSON::PP;

sub normalize {
    my $value = NFKD(fc($_[0]));
    $value =~ s/\p{M}//g;
    return $value;
}

sub decode_path {
    my $value = shift;
    $value =~ tr/+/ /;
    for (1 .. 2) { $value =~ s/%([0-9a-fA-F]{2})/chr(hex($1))/eg; }
    return decode('UTF-8', $value);
}

my $path = "$ENV{HOME}/Library/Application Support/forScore Alfred/forscore-index.tsv";
my $query = decode('UTF-8', $ARGV[0] // '');
my @terms = split /\s+/, normalize($query);
my @items;
my ($app_path) = grep { -d $_ } (
    "$ENV{HOME}/Applications/forScore.app", '/Applications/forScore.app');
if (!-f $path) {
    push @items, {title => 'Run Export forScore Index - Shared in Shortcuts first',
        subtitle => 'Keep forScore open and wait for the export to finish.', valid => JSON::PP::false};
} elsif (open my $in, '<:encoding(UTF-8)', $path) {
    while (my $row = <$in>) {
        $row =~ s/\r?\n\z//;
        my ($title, $url) = $row =~ /\A(.+)\t(forscore:\/\/open\?[^\s<>]+)\z/;
        next unless defined $url;
        my ($encoded_parent) = $url =~ /[?&]path=([^&]+)/;
        next unless defined $encoded_parent;
        my $parent = decode_path(encode('UTF-8', $encoded_parent));
        my $haystack = normalize("$title $parent");
        next if grep { index($haystack, $_) < 0 } @terms;
        my $kind = $url =~ /[?&]bookmark=/ ? 'Bookmark' : 'Score';
        (my $safe_title = $title) =~ s/([\\\[\]])/\\$1/g;
        push @items, {uid => $url, title => $title,
            subtitle => "$kind \x{2022} $parent", arg => $url,
            text => {copy => "[$safe_title](<$url>)"}, autocomplete => $title};
        last if @items >= 200;
    }
    close $in;
    push @items, {title => 'No matching scores or bookmarks', valid => JSON::PP::false} unless @items;
} else {
    push @items, {title => 'Cannot read the forScore index',
        subtitle => 'Run Export forScore Index - Shared again in Shortcuts.', valid => JSON::PP::false};
}
if ($app_path) {
    $_->{icon} = {type => 'fileicon', path => $app_path} for @items;
}
print JSON::PP->new->utf8->encode({items => \@items});
